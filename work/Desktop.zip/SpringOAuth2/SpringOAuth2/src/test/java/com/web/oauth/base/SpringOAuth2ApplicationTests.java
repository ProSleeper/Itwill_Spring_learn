package com.web.oauth.base;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringOAuth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
