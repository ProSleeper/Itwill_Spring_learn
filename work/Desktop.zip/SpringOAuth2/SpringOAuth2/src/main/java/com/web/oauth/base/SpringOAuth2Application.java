package com.web.oauth.base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOAuth2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringOAuth2Application.class, args);
	}

}
