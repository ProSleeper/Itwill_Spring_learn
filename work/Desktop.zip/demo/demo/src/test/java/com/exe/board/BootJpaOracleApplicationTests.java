package com.exe.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJpaOracleApplicationTests {

	@Test
	void contextLoads() {
	}

}
